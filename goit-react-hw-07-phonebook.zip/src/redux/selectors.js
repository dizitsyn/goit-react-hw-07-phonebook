const filterValue = (state) => state.contacts.filter;
export default { filterValue };
